import { View, Text, StyleSheet, Image } from "react-native";
const homeScreenImage = require("../../assets/images/homepage.jpg");

export default function HomeScreen() {
    return (
        <View style={styles.container}>
            <Image source={homeScreenImage} style={styles.image} />
            <Text style={styles.text}>Welcome to StreakMaster</Text>
            <Text style={styles.subText}>Explore habits, maintain streaks, and stay consistent one day at a time..</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20 },
    image: { width: 300, height: 300, marginBottom: 20, borderRadius: 10 },
    text: { fontSize: 24, fontWeight: "bold", textAlign: "center" },
    subText: { fontSize: 16, color: "gray", marginTop: 10, textAlign: "center" },
}); 