import React, { useState } from 'react';
import { View, Text, Switch, Alert, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const SettingsScreen = () => {
    const [notificationsEnabled, setNotificationsEnabled] = useState(false);
    const [darkTheme, setDarkTheme] = useState(false);

    const handleResetData = () => {
        Alert.alert(
            'Reset All Data',
            'Are you sure you want to delete all your streaks and habits?',
            [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Reset', style: 'destructive', onPress: () => console.log('Data reset') },
            ]
        );
    };

    return (
        <View style={{ flex: 1, backgroundColor: darkTheme ? '#111827' : '#fff', padding: 20 }}>
            <Text style={{ fontSize: 24, fontWeight: 'bold', color: darkTheme ? '#fff' : '#000', marginBottom: 20 }}>
                Settings
            </Text>

            {/* Notification Toggle */}
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                <Text style={{ fontSize: 16, color: darkTheme ? '#fff' : '#000' }}>Daily Notifications</Text>
                <Switch
                    value={notificationsEnabled}
                    onValueChange={setNotificationsEnabled}
                    thumbColor={notificationsEnabled ? '#10B981' : '#ccc'}
                />
            </View>

            {/* Theme Toggle */}
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                <Text style={{ fontSize: 16, color: darkTheme ? '#fff' : '#000' }}>Dark Theme</Text>
                <Switch
                    value={darkTheme}
                    onValueChange={setDarkTheme}
                    thumbColor={darkTheme ? '#6366F1' : '#ccc'}
                />
            </View>

            {/* Reset Data Button */}
            <TouchableOpacity
                onPress={handleResetData}
                style={{
                    marginTop: 30,
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: '#EF4444',
                    paddingVertical: 12,
                    paddingHorizontal: 16,
                    borderRadius: 12,
                }}
            >
                <Ionicons name="trash" size={20} color="#fff" />
                <Text style={{ color: '#fff', marginLeft: 10, fontSize: 16 }}>Reset All Data</Text>
            </TouchableOpacity>
        </View>
    );
};

export default SettingsScreen;
