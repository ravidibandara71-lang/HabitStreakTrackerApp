import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";

export default function ProfileScreen() {
    // Mock user data
    const user = {
        name: "Username",
        email: "example@gmail.com",
        streak: 0,
        habitsTracked: 0,
        // placeholder avatar
    };

    const handleEditProfile = () => {
        // Logic for editing profile (e.g., navigation to edit screen)
        console.log("Edit profile pressed");
    };

    return (
        <View style={styles.container}>

            <Text style={styles.name}>{user.name}</Text>
            <Text style={styles.email}>{user.email}</Text>

            <View style={styles.statsContainer}>
                <View style={styles.statBox}>
                    <Text style={styles.statValue}>{user.streak}</Text>
                    <Text style={styles.statLabel}>Day Streak</Text>
                </View>
                <View style={styles.statBox}>
                    <Text style={styles.statValue}>{user.habitsTracked}</Text>
                    <Text style={styles.statLabel}>Habits Tracked</Text>
                </View>
            </View>

            <TouchableOpacity style={styles.editButton} onPress={handleEditProfile}>
                <Text style={styles.editButtonText}>Edit Profile</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        alignItems: "center",
        backgroundColor: "#fff",

    },
    name: {
        fontSize: 24,
        fontWeight: "bold",
        marginBottom: 5,
    },
    email: {
        fontSize: 16,
        color: "#666",
        marginBottom: 20,
    },
    statsContainer: {
        flexDirection: "row",
        justifyContent: "space-around",
        width: "100%",
        marginBottom: 30,
    },
    statBox: {
        alignItems: "center",
    },
    statValue: {
        fontSize: 22,
        fontWeight: "bold",
    },
    statLabel: {
        fontSize: 14,
        color: "#888",
    },
    editButton: {
        backgroundColor: "#4CAF50",
        paddingVertical: 12,
        paddingHorizontal: 30,
        borderRadius: 10,
    },
    editButtonText: {
        color: "#fff",
        fontSize: 16,
        fontWeight: "bold",
    },
}); 