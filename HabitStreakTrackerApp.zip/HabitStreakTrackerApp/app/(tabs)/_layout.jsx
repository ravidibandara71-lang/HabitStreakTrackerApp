import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";

export default function Layout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: "blue",  // Active tab color 
        tabBarInactiveTintColor: "gray", // Inactive tab color 
        tabBarStyle: { backgroundColor: "white", height: 60 }, // Tab bar style 
      }}
    >
      <Tabs.Screen
        name="index" // Ensure the name matches the file name (index.js for Home) 
        options={{
          title: "Home",  // Tab title 
          tabBarLabel: "Home",  // Label for the tab 
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home-outline" size={size} color={color} />  // Icon with dynamic color 
          ),
        }}
      />
      <Tabs.Screen
        name="profile" // Ensure this matches the file name for the profile screen 
        options={{
          title: "Profile",  // Tab title 
          tabBarLabel: "Profile",  // Label for the tab 
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="person-outline" size={size} color={color} />  // Icon with dynamic color 
          ),
        }}
      />
      <Tabs.Screen
        name="settings" // Ensure this matches the file name for the settings screen 
        options={{
          title: "Settings",  // Tab title 
          tabBarLabel: "Settings",  // Label for the tab 
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="settings-outline" size={size} color={color} />  // Icon with dynamic color

          ),
        }}
      />
    </Tabs>
  );
} 