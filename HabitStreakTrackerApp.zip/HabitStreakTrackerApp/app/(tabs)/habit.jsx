import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const habitsData = [
    { id: '1', name: 'Exercise' },
    { id: '2', name: 'Read' },
    { id: '3', name: 'Drink Water' },
    { id: '4', name: 'Reading Books' },
    { id: '5', name: 'Listening to music' },
];

export default function HabitTrackerScreen() {
    const [habits, setHabits] = useState({
        '1': false,
        '2': false,
        '3': false,

    });

    const toggleHabit = (id) => {
        setHabits({ ...habits, [id]: !habits[id] });

    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>HABIT STREAK</Text>

            <View style={styles.streakRow}>
                {daysOfWeek.map((day, index) => (
                    <View key={index} style={styles.dayCircle}>
                        <Text style={styles.dayText}>{day}</Text>
                    </View>
                ))}
            </View>

            <FlatList
                data={habitsData}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={styles.habitRow}
                        onPress={() => toggleHabit(item.id)}
                    >
                        <Text style={styles.habitText}>{item.name}</Text>
                        <Ionicons
                            name={habits[item.id] ? 'checkmark-circle' : 'ellipse-outline'}
                            size={28}
                            color={habits[item.id] ? 'green' : 'gray'}
                        />
                    </TouchableOpacity>
                )}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        marginBottom: 20,
        alignSelf: 'center',
    },
    streakRow: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 30,
    },
    dayCircle: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: '#eee',
        justifyContent: 'center',
        alignItems: 'center',
    },
    dayText: {
        fontWeight: 'bold',
    },
    habitRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderColor: '#ccc',
    },
    habitText: {
        fontSize: 18,
    },
});
